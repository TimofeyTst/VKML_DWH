#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""mr3_join_mapper.py"""

import sys

for line in sys.stdin: 
    print line.strip()
